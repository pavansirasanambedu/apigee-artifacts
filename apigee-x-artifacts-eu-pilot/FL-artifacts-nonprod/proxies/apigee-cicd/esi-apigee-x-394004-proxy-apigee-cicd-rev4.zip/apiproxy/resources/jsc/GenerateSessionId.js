var sessionId = Math.random().toString(36).substring(2);
context.setVariable("session.id", sessionId);